export const iconSizes = {};

export const textSizes = {
  sm: 28,
  md: 30,
  lg: 120,
};
